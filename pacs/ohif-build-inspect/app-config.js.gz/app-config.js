/**
 * OHIF runtime configuration for the RCMS local viewer.
 *
 * Mounted into the ohif/app container at /usr/share/nginx/html/app-config.js
 * (see docker-compose `ohif` service). The single DICOMweb data source uses
 * relative roots so every QIDO/WADO request is same-origin to the OHIF
 * container (http://localhost:3005). The viewer receives a short-lived,
 * study-scoped token through OHIF's supported `token` query parameter. OHIF
 * installs it in its authentication service and removes it from the URL before
 * requesting metadata or pixels. Orthanc is never exposed to the browser.
 */
if (typeof window !== 'undefined') {
  if (typeof window.__filename === 'undefined') {
    window.__filename = '/app.bundle.js';
  }
  if (typeof window.__dirname === 'undefined') {
    window.__dirname = '/';
  }
  if (typeof window.process === 'undefined') {
    window.process = { env: {}, browser: true };
  } else if (!window.process.env) {
    window.process.env = {};
  }
}

try {
  const shownTours = JSON.parse(localStorage.getItem('shownTours') || '[]');
  if (!shownTours.includes('basicViewerTour')) {
    localStorage.setItem('shownTours', JSON.stringify([...shownTours, 'basicViewerTour']));
  }
} catch {
  localStorage.setItem('shownTours', JSON.stringify(['basicViewerTour']));
}

// dicomweb-client reports canceled XHRs as a generic `request failed` error
// with status 0. Series changes and request-pool cleanup can cause those
// cancellations during normal use. Prevent the production error overlay for
// that one expected case while preserving real HTTP and offline failures.
window.addEventListener('unhandledrejection', function (event) {
  const reason = event.reason;
  if (
    navigator.onLine &&
    reason &&
    reason.message === 'request failed' &&
    Number(reason.status || 0) === 0
  ) {
    event.preventDefault();
  }
});

window.config = {
  routerBasename: '/',
  showStudyList: false,
  investigationalUseDialog: { option: 'never' },
  whiteLabeling: {
    createLogoComponentFn: function (React) {
      return React.createElement(
        'div',
        { className: 'flex items-center gap-2 text-white' },
        React.createElement(
          'span',
          { className: 'bg-primary-main flex h-7 w-7 items-center justify-center rounded text-xs font-bold' },
          'R'
        ),
        React.createElement(
          'span',
          { className: 'hidden text-sm font-semibold sm:block' },
          'RCMS Imaging'
        )
      );
    },
  },
  extensions: [],
  modes: [],
  maxNumberOfWebWorkers: 3,
  showLoadingIndicator: true,
  showCPUFallbackMessage: true,
  showWarningMessageForCrossOrigin: false,
  strictZSpacingForVolumeViewport: true,
  groupEnabledModesFirst: true,
  maxNumRequests: {
    interaction: 12,
    thumbnail: 4,
    prefetch: 4,
  },
  dataSources: [
    {
      namespace: '@ohif/extension-default.dataSourcesModule.dicomweb',
      sourceName: 'dicomweb',
      configuration: {
        friendlyName: 'RCMS PACS',
        name: 'RCMS',
        qidoRoot: '/api/pacs/dicom-web',
        wadoRoot: '/api/pacs/dicom-web',
        wadoUriRoot: '/api/pacs/dicom-web',
        imageRendering: 'wadors',
        thumbnailRendering: 'wadors',
        enableStudyLazyLoad: true,
        qidoSupportsIncludeField: true,
        supportsFuzzyMatching: false,
        supportsWildcard: true,
        supportsReject: false,
        dicomUploadEnabled: false,
        omitQuotationForMultipartRequest: true,
      },
      onConfiguration: (dicomWebConfig, options) => {
        const urlParams = new URLSearchParams(window.location.search);
        const token = urlParams.get('token');
        if (token) {
          sessionStorage.setItem('rcms_viewer_token', token);
          dicomWebConfig.headers = dicomWebConfig.headers || {};
          dicomWebConfig.headers.Authorization = `Bearer ${token}`;
        } else {
          // RCMS uses a same-site, HTTP-only PACS cookie. Never reuse a token
          // left by an older query-string session after the cookie is renewed.
          sessionStorage.removeItem('rcms_viewer_token');
          if (dicomWebConfig.headers) {
            delete dicomWebConfig.headers.Authorization;
          }
        }
        
        return dicomWebConfig;
      }
    },
  ],
  defaultDataSourceName: 'dicomweb',
};
